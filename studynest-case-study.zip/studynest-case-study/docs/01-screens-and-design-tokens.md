# 12 High-Fidelity Screens (390×844)

| # | Screen | Key components | Tokens used |
|---|---|---|---|
| 1 | Splash | Logo, tagline, loader | primary bg, white text |
| 2 | Onboarding (3 slides) | Illustration, title, dots, Next/Skip | h1, body, primary |
| 3 | Login / Sign up | Inputs, primary button, Google sign-in | radius md, border, error |
| 4 | Home dashboard | Greeting, today's tasks, streak card, bottom nav | card shadow, h2, accent |
| 5 | Add Task (bottom sheet) | Title, subject chip, date picker, priority, Save | sheet shadow, radius lg |
| 6 | Weekly Planner | Day selector, time-blocked list, FAB | primary-light, caption |
| 7 | Focus Timer | Circular timer, Start/Pause, session presets | primary, h1 |
| 8 | Subjects | Subject cards with progress bars, color tags | surface, success |
| 9 | Progress | Weekly bar chart, hours studied, completion % | accent, success |
| 10 | Streaks & Rewards | Streak flame, badges grid | accent, radius full |
| 11 | Settings | Notifications, theme, account list | text-secondary, border |
| 12 | Empty / Success state | Illustration, message, CTA | h2, body, primary |

## Component library
Buttons (primary / secondary / ghost, 3 states), inputs (default / focus / error), task card, subject chip, bottom nav (5 items), bottom sheet, toast.

## Accessibility
- Text contrast ≥ 4.5:1 (primary on white = 6.1:1)
- Touch targets ≥ 44×44px
- Icons always paired with labels in the nav
