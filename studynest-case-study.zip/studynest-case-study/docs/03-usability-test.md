# Usability Test Report (Simulated)

> This test is **simulated** per the project brief. Participants are representative personas, not real people.

**Prototype:** StudyNest v1 · **Method:** moderated, think-aloud · **Participants:** 5 (college students, age 18-22)

## Script
1. "Imagine you have an assignment due Friday. Add it to the app."
2. "You want to study for 25 minutes without distractions. Start a session."
3. "Check how much you studied this week."

## Results
| Task | P1 | P2 | P3 | P4 | P5 | Success | Avg. time |
|---|---|---|---|---|---|---|---|
| 1. Add task | ✅ | ✅ | ✅ | ✅ | ✅ | 5/5 | 14s |
| 2. Start timer | ✅ | ✅ | ❌ | ✅ | ✅ | 4/5 | 18s |
| 3. Check progress | ❌ | ✅ | ❌ | ✅ | ✅ | 3/5 | 22s |

## Findings and fixes
| # | Issue | Severity | Fix |
|---|---|---|---|
| 1 | Users didn't recognize the "Stats" tab as progress | High | Renamed to "Progress", new chart icon |
| 2 | Start button on timer felt small | Medium | Enlarged to 72px circle, primary color |
| 3 | No visible way to add a task from Planner | Medium | Added FAB on Planner |
| 4 | Date picker defaulted to today, confusing | Low | Added quick chips: Today / Tomorrow / Pick |

## Quotes
- "Adding a task was super quick." (P2)
- "Where do I see my hours? I thought Stats was something else." (P1)

## Re-test
After fixes, Task 3 success improved to 5/5 and avg. time dropped to 11s.
