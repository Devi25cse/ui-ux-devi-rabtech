# Prototype Interaction Plan

## Screen connections
| From | Trigger | To | Animation |
|---|---|---|---|
| Splash | After delay 1.5s | Onboarding 1 | Dissolve 300ms |
| Onboarding 1→3 | Tap Next | Next slide | Move in (left), ease-out |
| Onboarding 3 | Tap Get Started | Login | Push |
| Login | Tap Login | Home | Smart Animate |
| Home | Tap + / FAB | Add Task sheet | **Overlay** (bottom, scrim 40%) |
| Add Task | Tap Save | Home | Close overlay + toast |
| Home / Nav | Tap Planner | Planner | Instant (tab) |
| Planner | Tap a task | Focus Timer | Smart Animate |
| Focus Timer | Tap Start | Timer running | Smart Animate (ring) |
| Nav | Tap Progress | Progress | Instant |
| Progress | Tap streak card | Streaks | Push |
| Home | Tap profile | Settings | Slide in right |

## Smart animations
1. Timer ring: stroke progress animates 100% → 0% (ease-in-out, 1s)
2. Home → Planner card expands into a full task view
3. Progress bars grow from 0 on screen load

## Overlays
- Add Task bottom sheet (swipe-down to dismiss)
- Delete-confirmation modal
- Date picker popup

## Micro-interactions
- Checkbox tick: scale 1→1.2→1 with confetti burst (200ms)
- Streak flame: gentle pulse loop
- Button press: scale 0.96, color shift to darker primary
- Input focus: border animates to primary
- Toast: slides up, auto-dismisses in 2s
