# Submission Checklist

- [ ] Figma: 12 screens built using the tokens in `design/design-tokens.json`
- [ ] Prototype connections added per `docs/02-prototype-interactions.md`
- [ ] Figma share → **"Anyone with the link can view"**; open the link in incognito to confirm
- [ ] Wireframes + final screens exported to `/design`
- [ ] README: replace the `<ADD YOUR PUBLIC FIGMA PROTOTYPE LINK>` placeholder
- [ ] Export case study as PDF (Markdown → PDF) **or** publish on Behance / Medium
- [ ] Submit ONE public link on the portal (Figma prototype link + PDF/Behance link)
