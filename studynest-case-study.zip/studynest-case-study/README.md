# StudyNest: Study Planner App (UI/UX Case Study)

> High-fidelity Figma prototype, usability test and capstone case study.

**Role:** UI/UX Designer · **Tools:** Figma, FigJam, Notion · **Platform:** Mobile (iOS/Android, 390×844)
**Prototype:** `<ADD YOUR PUBLIC FIGMA PROTOTYPE LINK>`

---

## 1. Overview
StudyNest helps college students plan their week, stay focused with a timer, and see their progress, all in one calm, low-friction app.

## 2. Problem
Students juggle classes, assignments and exams across WhatsApp groups, notes apps and calendars. The result: missed deadlines, last-minute cramming and low motivation.

**Problem statement:** *How might we help students plan study time quickly and stay consistent, without the planner itself becoming another chore?*

## 3. Research
> Note: Research below is desk research plus a small informal survey. Replace the numbers with your own if you run a real one.

**Methods:** competitor review (Notion, Todoist, Forest, Google Calendar), a short survey, 3 informal interviews.

**Key insights**
1. Students abandon planners because setup takes too long.
2. Deadlines are scattered across multiple apps.
3. Seeing progress (streaks, hours studied) is motivating.
4. Phone distraction during study is the biggest focus killer.

**Persona: Karthik, 20, engineering student**
- Goals: finish assignments on time, study 2 focused hours daily
- Pain points: forgets deadlines, procrastinates, loses focus on the phone
- Needs: a fast way to add tasks, reminders, a focus mode

## 4. Ideation and Information Architecture
**Features (MoSCoW)**
- Must: quick-add task, weekly planner, focus timer, subjects
- Should: progress analytics, streaks
- Could: study-group sharing, themes

**Flow:** Onboarding → Home → Add Task → Planner → Focus Timer → Progress

## 5. Wireframes
Low-fidelity wireframes covered 12 screens, tested on paper and in Figma for flow before visual design.
`/design/wireframes/` ← add your exported wireframe images here.

## 6. Visual Design
Calm, friendly and focused: warm off-white backgrounds, an indigo primary and an amber accent for rewards.
Full token list: [`design/design-tokens.json`](design/design-tokens.json) · Screen specs: [`docs/01-screens-and-design-tokens.md`](docs/01-screens-and-design-tokens.md)

| Token | Value |
|---|---|
| Primary | `#5B4CF0` |
| Accent | `#FFB020` |
| Background | `#FAF8F5` |
| Text | `#1F1D2B` |
| Heading font | Poppins SemiBold |
| Body font | Inter Regular |
| Grid / radius | 8pt / 12px |

## 7. Interactive Prototype
12 high-fidelity screens with smart animations, overlays and micro-interactions. Full spec: [`docs/02-prototype-interactions.md`](docs/02-prototype-interactions.md)

Highlights: bottom-sheet quick-add (overlay), animated timer ring (Smart Animate), checkbox confetti micro-interaction, streak flame pulse.

## 8. Usability Testing (Simulated)
3 tasks, 5 simulated participants. Full report: [`docs/03-usability-test.md`](docs/03-usability-test.md)

| Task | Success rate | Avg. time |
|---|---|---|
| Add a task with deadline | 5/5 | 14s |
| Start a 25-min focus session | 4/5 | 18s |
| Check weekly progress | 3/5 → 5/5 after fix | 22s → 11s |

**Top fixes:** clearer Progress tab label and icon, larger Start button on the timer, a visible "Add" FAB on Planner.

## 9. Final Outcome
A consistent, accessible (WCAG AA contrast) 12-screen prototype that lets a student add a task in under 15 seconds.

## 10. Learnings
- Speed of the first action matters more than feature count.
- Even small testing rounds expose obvious navigation issues.
- A token-based design system made 12 screens consistent and fast to build.

## 11. Next Steps
Real-user testing, dark mode, study-group sharing, and developer handoff.

---
## Repository structure
```
studynest-case-study/
├── README.md
├── design/
│   ├── design-tokens.json
│   └── (wireframes, final screens, exports)
└── docs/
    ├── 01-screens-and-design-tokens.md
    ├── 02-prototype-interactions.md
    ├── 03-usability-test.md
    └── 04-submission-checklist.md
```
